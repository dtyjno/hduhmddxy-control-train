OLD versions of GeographicLib
=============================

This is where you will find pre-2.0 versions of GeographicLib.  For
newer versions of the C++ library, go to
https://sourceforge.net/projects/geographiclib/files/distrib-C++

For information about the implementations in other languages, see

> https://geographiclib.sourceforge.io/doc/library.html#languages

Programmers should download the latest `.tar.gz` or `.zip` file.  The
`.exe` files provide Windows installers for the utilities (and the
library compiled with Visual Studio 14 2015).

For installation instructions, see

> https://geographiclib.sourceforge.io/C++/doc/install.html
